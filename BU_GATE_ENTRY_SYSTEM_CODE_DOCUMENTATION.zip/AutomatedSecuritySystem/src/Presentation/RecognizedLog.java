/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation;
import Database.People;
import java.util.ArrayList;
/**
 *
 * @author Afia Fahmida Rahman
 */
public class RecognizedLog {
    
    ArrayList <People> a;
    
    /**
     * 
     * @param p Adds the recognized people into a log which is an array list
     */
    RecognizedLog(People p){
    
    }
}
