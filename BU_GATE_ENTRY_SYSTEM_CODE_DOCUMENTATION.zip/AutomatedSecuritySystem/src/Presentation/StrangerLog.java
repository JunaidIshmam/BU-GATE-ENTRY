/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation;
import Database.People;
import java.util.ArrayList;
/**
 *
 * @author Afia Fahmida Rahman
 */

public class StrangerLog {
    /**
     * 
     * @param p Adds the unrecognized people into a log which is an array list
     */
    public StrangerLog(People p){
    
    }
}
