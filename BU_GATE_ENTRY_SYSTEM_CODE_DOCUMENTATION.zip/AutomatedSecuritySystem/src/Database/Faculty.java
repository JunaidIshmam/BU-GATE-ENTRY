/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

/**
 *
 * @author Afia Fahmida Rahman
 */
public class Faculty extends People{
    String name;
    int id;
    /**
     * 
     * @param name Contains the name of the faculty
     * @param id Contains the Id of the faculty
     */
    Faculty(String name, int id){
        super(name,"faculty");
        this.id=id;
    }
    
    /**
     * 
     * @return It returns the id number of the faculty
     */
    public int getIDcode(){
        return id;
    }
}
