/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

/**
 *
 * @author Afia Fahmida Rahman
 */
public class Student extends People{
    String name;
    int id;
    /**
     * 
     * @param name Accepts the name of the student and passes it to People class; later an id card code and fingerprint are saved in people constructor 
     */
    Student(String name, int id){
        super(name,"student");
        this.id=id;
    }
    /**
     * 
     * @return it returns the id number of the student
     */
    public int getIDcode(){
        return id;
    }
}
