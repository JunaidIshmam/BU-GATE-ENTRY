/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

/**
 *
 * @author Afia Fahmida Rahman
 */

/**
 * 
 * @author AfiaVader
 */
public abstract class People {
    
    /**
     * 
     */
    String name; 
    
    Fingerprint f;
    String role;
    
    /**
     * 
     * @param name Accepts the name of the person and stores it
     * @param role Accepts the role of the person in the university premises, eg. student, faculty, etc.
     * This constructor later asks for the person's fingerprint by calling the saveFingerprint(finger) method
     */
    public People(String name, String role){
        saveFingerprint(new Fingerprint(10101100));
        saveIDcardCode(getIDcode());
    }
    
    /**
     * 
     * @param finger Accepts a fingerprint and saves it here in the instance variable
     */
    public static void saveFingerprint(Fingerprint finger){
        
    }
}
