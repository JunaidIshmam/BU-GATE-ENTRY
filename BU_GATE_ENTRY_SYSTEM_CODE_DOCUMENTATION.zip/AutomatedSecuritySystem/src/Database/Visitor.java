/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

/**
 *
 * @author Afia Fahmida Rahman
 */
public class Visitor extends People{
    public static int id=0;
    /**
     * 
     * @param name Accepts the name of the visitor. This method later assigns an ID to him/her
     */
    public Visitor(String name){
        super(name,"visitor");
    }
    /**
     * 
     * @return This returns a unique Id for each person to enter the campus.
     */
    public int getIDcode(){
        id++;
        return id;
    }
}
