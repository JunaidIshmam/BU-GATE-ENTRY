/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

/**
 *
 * @author Afia Fahmida Rahman
 */
public class Staff extends People{
    String name;
    int id;
    /**
     * 
     * @param name Accepts the name of the staff
     * @param id Accepts the name of the id and stores it in the database
     */
    Staff(String name, int id){
        super(name,"staff");
        this.id=id;
    }
    
    /**
     * 
     * @return Returns the id of the staff
     */
    public int getIDcode(){
        return id;
    }
}
