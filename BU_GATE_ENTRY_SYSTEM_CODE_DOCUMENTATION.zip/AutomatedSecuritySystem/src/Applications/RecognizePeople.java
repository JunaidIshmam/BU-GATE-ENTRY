/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Applications;
import Database.Fingerprint;

/**
 *
 * @author Afia Fahmida Rahman
 */


public class RecognizePeople {
    /**
     * 
     * @param f This constructor accepts a fingerprint, looks up the people database and matches with existing fingerprint data already stored in the system. If 
     * it recognizes the person, they are allowed to go inside the campus. If not, the registrar is contacted.
     */
    public RecognizePeople(Fingerprint f){
        if(recognized(f)){ 
            
            System.out.println("Go");
                    }
    
        else
            System.out.println(contactRegistrar());
    }
    /**
     * 
     * @return this method calls the registrar and asks for permission of entrance of the undocumented individual trying to enter. If they are allowed, it returns true
     */
    public boolean contactRegistrar(){
        return false;
    }
    
    /**
     * 
     * @param f The parameter accepted is the fingerprint data of the incoming person.
     * @return Once the database is checked, if it matches a saved fingerprint, the method returns true. Else, false is returned.
     */
    public boolean recognized(Fingerprint f){
     return true;
    }
}
