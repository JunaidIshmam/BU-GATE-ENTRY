/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Applications;

/**
 *
 * @author Afia Fahmida Rahman
 */
public class Registrar {
    /**
     * 
     * @return This method checks for the person in the expected visitors list. It returns true if the person is recognized as an expected visitor, false otherwise.
     */
    public boolean lookup(){
     return false;
    }
    
}
