/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Applications;
import Database.Fingerprint;
/**
 *
 * @author Afia Fahmida Rahman
 */

public class AccessPeople {
    
    /**
     * 
     * @param request This constructor accepts a boolean value. If it is false, the system stays as it is. If true, the person to be identified is then looked up in the People database using the ID number
     */
    public AccessPeople(boolean request){
    
    }
    /**
     * 
     * @param f Upon the input of a fingerprint, this method starts looking for information about the person
     * @return Returns the name, id, role of the person in one concatenated string.
     */
    public String getInfo(Fingerprint f){
     return "";
    }
    
}
